# Installs chkrootkit rkhunter and clamtk
apt-get install -y chkrootkit rkhunter clamav

# rkhunter | Updates database and enables protection
rkhunter --update
rkhunter --propupd
rkhunter -c --enable all --disable none

#chkrootkit | runs scan
chkrootkit -q > chkrootkit.log
less chkrootkit.log

#clam
freahclam
clamscan -r -i > clam.log
less clam.log