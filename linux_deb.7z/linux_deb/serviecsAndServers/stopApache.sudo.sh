service apache2 stop
systemctl stop apache2.service