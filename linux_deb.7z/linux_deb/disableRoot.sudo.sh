sed -i 's/root:x:0:0:root:%root:%bin%bash/root:x:0:0:root:%root:%sbin%nologin/g' /etc/passwd
passwd -l root
usermod -p '!' root
